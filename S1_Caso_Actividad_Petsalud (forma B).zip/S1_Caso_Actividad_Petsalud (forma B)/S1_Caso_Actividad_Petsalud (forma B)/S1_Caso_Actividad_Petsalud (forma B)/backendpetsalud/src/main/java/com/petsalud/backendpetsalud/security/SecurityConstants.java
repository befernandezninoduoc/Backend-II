package com.petsalud.backendpetsalud.security;

public final class SecurityConstants {

    // Roles del sistema
    public static final String ROL_ADMIN = "ADMIN";
    public static final String ROL_VETERINARIO = "VETERINARIO";
    public static final String ROL_CLIENTE = "CLIENTE";
    public static final String ROL_EMPLEADO = "EMPLEADO";

    // Rutas y patrones de endpoints repetidos
    public static final String RUTA_PRODUCTOS = "/api/productos/**";

    private SecurityConstants() {
        // Constructor privado para evitar la instanciación de una clase utilitaria
    }
}
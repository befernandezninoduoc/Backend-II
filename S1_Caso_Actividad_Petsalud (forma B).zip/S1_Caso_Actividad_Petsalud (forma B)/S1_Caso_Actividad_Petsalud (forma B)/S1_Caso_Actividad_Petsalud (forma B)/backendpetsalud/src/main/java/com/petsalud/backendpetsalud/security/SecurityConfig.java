package com.petsalud.backendpetsalud.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import com.petsalud.backendpetsalud.repository.UsuarioRepository;

import static org.springframework.security.config.Customizer.withDefaults;
import static com.petsalud.backendpetsalud.security.SecurityConstants.*;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private static final Logger logger = LoggerFactory.getLogger(SecurityConfig.class);

    // Actualiza automáticamente el hash en BD al arrancar la app para evitar errores 401
    @Bean
    CommandLineRunner inicializarAdmin(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            usuarioRepository.findByEmail("admin@petsalud.cl").ifPresent(admin -> {
                admin.setPassword(passwordEncoder.encode("123456"));
                usuarioRepository.save(admin);
                logger.info(">>> [SECURITY] Contraseña de admin@petsalud.cl sincronizada correctamente a '123456' <<<");
            });
        };
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf
                        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                )
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers(HttpMethod.POST, "/api/usuarios/registro").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/productos", "/api/productos/categoria").permitAll()

                        // Módulos protegidos con constantes de roles y rutas
                        .requestMatchers("/api/expedientes/**").hasAnyAuthority(ROL_VETERINARIO, ROL_ADMIN)
                        .requestMatchers("/api/ventas/**").hasAnyAuthority(ROL_EMPLEADO, ROL_ADMIN)

                        // Uso de la constante RUTA_PRODUCTOS para evitar duplicación
                        .requestMatchers(HttpMethod.POST, RUTA_PRODUCTOS).hasAnyAuthority(ROL_EMPLEADO, ROL_ADMIN)
                        .requestMatchers(HttpMethod.PUT, RUTA_PRODUCTOS).hasAnyAuthority(ROL_EMPLEADO, ROL_ADMIN)
                        .requestMatchers(HttpMethod.DELETE, RUTA_PRODUCTOS).hasAnyAuthority(ROL_EMPLEADO, ROL_ADMIN)
                        .requestMatchers("/api/productos/stock-bajo").hasAnyAuthority(ROL_EMPLEADO, ROL_ADMIN)

                        .requestMatchers(HttpMethod.GET, "/api/usuarios").hasAuthority(ROL_ADMIN)
                        .requestMatchers("/api/citas/**").hasAnyAuthority(ROL_CLIENTE, ROL_VETERINARIO, ROL_ADMIN)
                        .requestMatchers("/api/mascotas/**").hasAnyAuthority(ROL_CLIENTE, ROL_VETERINARIO, ROL_ADMIN)
                        .requestMatchers("/api/recompensas/**").hasAnyAuthority(ROL_CLIENTE, ROL_ADMIN)
                        .requestMatchers("/api/notificaciones/**").authenticated()

                        .anyRequest().authenticated()
                )
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                )
                .httpBasic(withDefaults());

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }
}